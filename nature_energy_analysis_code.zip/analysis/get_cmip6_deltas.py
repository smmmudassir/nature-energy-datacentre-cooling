"""Monthly CMIP6 change signals (tas, hurs) at study sites from the Pangeo CMIP6 archive on Google Cloud.

Delta = mean(2041-2060) - mean(2015-2024) within the same SSP run (matching the ERA5 2015-2025 baseline), by calendar month, per model.
"""
import pandas as pd, numpy as np, xarray as xr, gcsfs, json, sys
from concurrent.futures import ThreadPoolExecutor

SITES = {'Hyderabad': (17.45, 78.38), 'Mumbai': (19.10, 72.90), 'Chennai': (13.00, 80.20), 'Phoenix': (33.45, 247.95)}
MODELS = ['ACCESS-CM2', 'MPI-ESM1-2-HR', 'CanESM5', 'EC-Earth3', 'GFDL-ESM4', 'IITM-ESM', 'INM-CM5-0', 'IPSL-CM6A-LR',
          'MIROC6', 'MPI-ESM1-2-HR', 'MRI-ESM2-0', 'NorESM2-MM', 'CMCC-ESM2']
PERIOD = {'ssp245': ('2041', '2060'), 'ssp585': ('2041', '2060'), 'ssp245_base': ('2015', '2024'), 'ssp585_base': ('2015', '2024')}

cat = pd.read_csv('pangeo.csv')
cat = cat[(cat.table_id == 'Amon') & (cat.member_id == 'r1i1p1f1')]
fs = gcsfs.GCSFileSystem(token='anon')


def clim(model, exp, var):
    row = cat[(cat.source_id == model) & (cat.experiment_id == exp.replace('_base', '')) & (cat.variable_id == var)].sort_values('version').iloc[-1]
    ds = xr.open_zarr(fs.get_mapper(row.zstore), consolidated=True, use_cftime=True)
    ds = ds.sortby('time')
    a, b = PERIOD[exp]
    lon = ds['lon']
    out = {}
    for s, (la, lo) in SITES.items():
        lo2 = lo if float(lon.max()) > 180 else (lo - 360 if lo > 180 else lo)
        x = ds[var].sel(lat=la, lon=lo2, method='nearest').sel(time=slice(a, b)).load()
        m = x.groupby('time.month').mean().values
        out[s] = (m - 273.15 if var == 'tas' else m).tolist()
    return out


def job(args):
    model = args
    try:
        r = {exp: {v: clim(model, exp, v) for v in ('tas', 'hurs')} for exp in PERIOD}
        return model, r
    except Exception as e:
        print('FAILED', model, repr(e)[:200], file=sys.stderr, flush=True)
        return model, None


if __name__ == '__main__':
    res = {}
    with ThreadPoolExecutor(6) as ex:
        for m, r in ex.map(job, MODELS):
            if r:
                res[m] = r
                print('ok', m, flush=True)
    deltas = {}
    for m, r in res.items():
        deltas[m] = {}
        for ssp in ('ssp245', 'ssp585'):
            deltas[m][ssp] = {s: {'dT': (np.array(r[ssp]['tas'][s]) - np.array(r[ssp + '_base']['tas'][s])).tolist(),
                                  'dRH': (np.array(r[ssp]['hurs'][s]) - np.array(r[ssp + '_base']['hurs'][s])).tolist()}
                              for s in SITES}
    json.dump(deltas, open('cmip6_deltas.json', 'w'), indent=1)
    print('models', list(deltas))
