"""Figures for the first-pass analysis (static PNG for the manuscript)."""
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import pue_wue, wetbulb, CENTRAL, TECHS, INV, SITES

C = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100']   # categorical slots 1-4
INK, MUTED, GRID = '#222222', '#6b6b6b', '#e4e3df'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.edgecolor': MUTED, 'axes.labelcolor': INK,
                     'xtick.color': MUTED, 'ytick.color': MUTED, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.6, 'axes.axisbelow': True})
r = json.load(open('results.json'))
cache = pd.read_pickle('cache.pkl'); T, RH = cache['T'], cache['RH']


def save(fig, name):
    fig.savefig(f'fig_{name}.png', dpi=300, bbox_inches='tight', facecolor='white'); plt.close(fig)


# Fig 1: capacity
fig, ax = plt.subplots(figsize=(6.5, 3))
x = np.arange(len(SITES))
live = [INV[s]['live'] for s in SITES]; pipe = [INV[s]['pipeline'] for s in SITES]
ax.bar(x, live, 0.6, color=C[0], label='Live (end-2025)')
ax.bar(x, pipe, 0.6, bottom=np.array(live) + 20, color=C[1], label='Pipeline (committed, under construction, planned)')
for i in range(len(SITES)):
    ax.text(i, live[i] + pipe[i] + 80, f'{live[i]:,.0f} + {pipe[i]:,.0f}', ha='center', color=INK, fontsize=8)
ax.set_xticks(x, SITES); ax.set_ylabel('IT capacity (MW)'); ax.legend(frameon=False, loc='upper left')
ax.set_ylim(0, max(np.array(live) + np.array(pipe)) * 1.15)
save(fig, '1_capacity')

# Fig 2: PUE vs dry-bulb temperature (binned) by technology, per city; + economiser hours
fig, axes = plt.subplots(1, 2, figsize=(7.6, 3.2), gridspec_kw={'width_ratios': [1.3, 1], 'wspace': 0.45})
ax = axes[0]
s = 'Hyderabad'; Tdb = T[s].values; Twb = wetbulb(Tdb, RH[s].values)
bins = np.arange(np.floor(Tdb.min()), np.ceil(Tdb.max()) + 1, 1)
for i, tech in enumerate(TECHS):
    p, _, _ = pue_wue(Tdb, Twb, CENTRAL, tech)
    d = pd.Series(p).groupby(np.digitize(Tdb, bins)).mean()
    ax.plot(bins[d.index - 1] + 0.5, d.values, color=C[i], lw=2, label=tech)
ax.set_xlabel('Outdoor dry-bulb temperature (°C)'); ax.set_ylabel('PUE'); ax.set_title('a  Hyderabad: PUE vs temperature', loc='left', fontsize=9)
ax.legend(frameon=False, fontsize=7.5)
ax = axes[1]
w = 0.26
for i, tech in enumerate(TECHS):
    v = [r['sites'][s]['tech'][tech]['heat_penalty_pct'] for s in SITES]
    ax.bar(x + (i - 1) * w, v, w * 0.92, color=C[i], label=tech)
ax.set_xticks(x, ['Hyder-\nabad','Mumbai','Chennai','Phoenix'], fontsize=8); ax.set_ylabel('PUE in hottest 1% of hours\nvs annual mean (%)')
ax.set_title('b  Heat penalty by city', loc='left', fontsize=9)
save(fig, '2_pue_temperature')

# Fig 3: (a) data centre load in hottest hours as share of state peak (central build-out), air-cooled, actual vs fixed PUE
fig, axes = plt.subplots(1, 2, figsize=(7.6, 3.6), gridspec_kw={'wspace': 0.5})
ax = axes[0]
ind = ['Hyderabad', 'Mumbai', 'Chennai']
sc = 'Central build-out (60%)'
for j, (key, lab, col) in enumerate([('share_of_state_peak_fixedPUE_pct', 'Fixed annual-mean PUE', '#9a9a9a'),
                                     ('share_of_state_peak_hot1_pct', 'Weather-dependent PUE (hottest 1% of hours)', C[0])]):
    v = [r['sites'][s]['tech']['Air-cooled chiller']['scenarios'][sc][key] for s in ind]
    ax.bar(np.arange(3) + (j - 0.5) * 0.36, v, 0.33, color=col, label=lab)
ax.set_xticks(np.arange(3), [f'{s}\n({r["sites"][s]["state"]})' for s in ind], fontsize=7.5)
ax.set_ylabel('Data centre load as % of\nrecent state record peak'); ax.legend(frameon=False, fontsize=7, loc='upper center', bbox_to_anchor=(0.5, -0.25), ncol=1)
ax.set_title('a  Central build-out, air-cooled', loc='left', fontsize=9)
ax = axes[1]
for i, tech in enumerate(TECHS):
    base = [r['sites'][s]['tech'][tech]['pue_hot1'] for s in SITES]
    w2 = [r['sites'][s]['tech'][tech]['warming']['+2C']['pue_hot1'] for s in SITES]
    v = [100 * (b2 / b - 1) for b, b2 in zip(base, w2)]
    ax.bar(x + (i - 1) * w, v, w * 0.92, color=C[i], label=tech)
ax.set_xticks(x, SITES, fontsize=8); ax.set_ylabel('Increase in hottest-hour PUE\nwith +2 °C warming (%)')
ax.set_title('b  Effect of +2 °C local warming', loc='left', fontsize=9); ax.legend(frameon=False, fontsize=7, loc='upper center', bbox_to_anchor=(0.5, -0.12), ncol=1)
save(fig, '3_peak_share_warming')

# Fig 4: mitigation
fig, ax = plt.subplots(figsize=(7.6, 3.4))
opts = list(r['mitigation_central']['Hyderabad']['options'].keys())
w4 = 0.2
for i, s in enumerate(SITES):
    v = [r['mitigation_central'][s]['options'][o]['reduction_pct'] for o in opts]
    ax.bar(np.arange(len(opts)) + (i - 1.5) * w4, v, w4 * 0.92, color=C[i], label=s)
ax.set_xticks(np.arange(len(opts)), ['Switch to\nevaporative', 'Switch to\ndirect-to-chip liquid', '4-h thermal\nstorage', 'Shift 20%\nof IT load'], fontsize=7.5)
ax.set_ylabel('Reduction in peak-hour data\ncentre load vs air-cooled (%)'); ax.legend(frameon=False, ncol=4, fontsize=7.5, loc='upper center', bbox_to_anchor=(0.5, -0.2))
ax.axhline(0, color=MUTED, lw=0.8)
save(fig, '4_mitigation')
print('figs done')
