# First-pass analysis: data centre cooling, heat and grid peaks

Run order (Python 3 with pandas, numpy, h5py, fsspec, matplotlib, pyarrow):

1. `get_era5.py` extracts hourly ERA5 2 m temperature and dew point (2015–2025) for Hyderabad, Mumbai, Chennai and Phoenix from the NSF NCAR ERA5 copy on AWS. The outputs are already saved in `data/era5_*.csv`. To rerun it, split those files back into monthly files in `era5_cache/`, or download again.
2. `data/eia930_azps_srp.csv` holds hourly demand for the AZPS and SRP balancing areas, from the PUDL `out_eia930__hourly_operations` table.
3. `model.py` runs the cooling, water, peak-hour, warming, mitigation and Monte Carlo analysis and writes `results.json`.
4. `figs.py` writes the four figures in `figures/`.

All parameters and capacity sources are listed at the top of `model.py`. These are first-pass assumptions; see the author note in the manuscript.

## CMIP6 update

5. `get_cmip6_deltas.py` extracts monthly tas and hurs for 12 CMIP6 models from the Pangeo CMIP6 archive on Google Cloud. For SSP2-4.5 and SSP5-8.5 it computes monthly change signals for 2041–2060 relative to 2015–2024 and writes them to `cmip6_deltas.json`. It needs the `pangeo-cmip6.csv` catalogue from storage.googleapis.com/cmip6.
6. `cmip6_apply.py` applies those signals to the hourly ERA5 data and writes `results_cmip6.json`.

## Indian grid coincidence (added 2026-10-25)

- `india_grid.py` tests whether Indian grid peaks coincide with hot hours. Run from this folder after `model.py` has written `cache.pkl`: `python3 india_grid.py <folder with study1_hourly.csv and study3_states.csv>`. Output: `results_india_grid.json`.
- `fig5.py` draws `figures/fig_5_india_coincidence.png`.
- Inputs: Halcyon Vector, "India Power Grid: NLDC Daily PSP Reports" (Kaggle, CC BY-SA 4.0), uploaded by Kevin as archive.zip. `study1_hourly.csv` gives hourly regional demand (Jan 2019 to Apr 2024); its hourly series comes from a secondary Kaggle compilation, so spot-check it against official Grid-India reports. `study3_states.csv` gives daily state maximum demand (Dec 2018 to Sep 2026). The daily state series was cross-checked against Kevin's separate `corrected_peak_met_MW.csv` (correlation 0.98 to 1.00, median difference 0 MW).
- `liq_sensitivity.py` repeats the liquid-cooling results with a 45 °C supply (W45) and 90% liquid capture; output `results_liquid_sensitivity.json`.
