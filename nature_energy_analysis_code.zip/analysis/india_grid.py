"""Indian grid coincidence test: do regional and state demand peaks fall in the hours and days when data centre cooling works hardest?

Inputs (uploaded by Kevin, NLDC/Grid-India PSP derived, CC BY-SA 4.0, Halcyon Vector 2026 on Kaggle):
  study1_hourly.csv  hourly regional demand (MW), Jan 2019 - Apr 2024, IST
  study3_states.csv  daily state maximum demand met (MW), Dec 2018 - Sep 2026
Weather: ERA5 hourly (UTC) from cache.pkl, converted to IST by averaging the two UTC hours either side of each IST hour.
Peaks are ranked within each calendar year so that load growth does not push all peak hours into the last year.
"""
import json, sys, numpy as np, pandas as pd
from model import pue_wue, wetbulb, CENTRAL, TECHS, INV

D = sys.argv[1] if len(sys.argv) > 1 else '../upl_zip'
cache = pd.read_pickle('cache.pkl'); T, RH = cache['T'], cache['RH']
REGION = {'Hyderabad': 'Southern Region Hourly Demand', 'Chennai': 'Southern Region Hourly Demand', 'Mumbai': 'Western Region Hourly Demand'}
STATE = {'Hyderabad': 'Telangana', 'Chennai': 'Tamil Nadu', 'Mumbai': 'Maharashtra'}


def to_ist(x):
    """UTC hourly -> IST hourly (IST hh:00 = UTC hh-6:30, i.e. midway between UTC hh-6 and hh-5)."""
    a = x.copy(); a.index = a.index + pd.Timedelta(hours=6)
    b = x.copy(); b.index = b.index + pd.Timedelta(hours=5)
    return (a + b.reindex(a.index)) / 2


def top_within_year(s, q):
    """Boolean mask: value is in the top (1-q) of its own calendar year."""
    thr = s.groupby(s.index.year).transform(lambda v: v.quantile(q))
    return s >= thr


Ti = to_ist(T).dropna(); RHi = to_ist(RH).dropna()
idx = Ti.index.intersection(RHi.index)
Ti, RHi = Ti.loc[idx], RHi.loc[idx]

h = pd.read_csv(f'{D}/study1_hourly.csv', usecols=['datetime'] + sorted(set(REGION.values())), parse_dates=['datetime']).set_index('datetime')
st = pd.read_csv(f'{D}/study3_states.csv', parse_dates=['date'])
st = st[st.state.isin(STATE.values())].pivot_table(index='date', columns='state', values='max_demand_met_mw')
st = st[(st.index >= '2019-01-01') & (st.index <= '2025-12-31')]

out = {'sources': dict(hourly_regional=f'{h.index.min():%Y-%m-%d} to {h.index.max():%Y-%m-%d}',
                       daily_state=f'{st.index.min():%Y-%m-%d} to {st.index.max():%Y-%m-%d}'), 'sites': {}}
for s in REGION:
    r = {}
    # ---------- hourly: regional demand vs hub weather ----------
    dem = h[REGION[s]]
    j = dem.index.intersection(Ti.index)
    dem = dem.loc[j]; Tdb = Ti[s].loc[j].values; Twb = wetbulb(Tdb, RHi[s].loc[j].values)
    top1 = top_within_year(dem, 0.99).values
    hot10 = Tdb >= np.quantile(Ti[s].values, 0.90)   # hottest 10% of hours in the 2015-2025 climate
    rel = (dem / dem.groupby(dem.index.year).transform('mean')).values  # demand relative to its year mean
    hr = dict(region=REGION[s].replace(' Hourly Demand', ''), hours=int(len(j)),
              corr_T_demand_relative=float(np.corrcoef(Tdb, rel)[0, 1]),
              mean_T_all=float(Tdb.mean()), mean_T_top1pct_demand_hours=float(Tdb[top1].mean()),
              share_top1_demand_hours_in_hottest10pct=float(100 * hot10[top1].mean()),
              peak_hour_of_day_mode=int(pd.Series(dem.index.hour[top1]).mode()[0]),
              top1_by_hour=pd.Series(dem.index.hour[top1]).value_counts().sort_index().to_dict(),
              top1_by_month=pd.Series(dem.index.month[top1]).value_counts().sort_index().to_dict(), tech={})
    it = (INV[s]['live'] + 0.6 * INV[s]['pipeline']) * CENTRAL['u']
    for tech in TECHS:
        pue, _, _ = pue_wue(Tdb, Twb, CENTRAL, tech)
        hr['tech'][tech] = dict(pue_mean=float(pue.mean()), pue_top1_demand=float(pue[top1].mean()),
                                coincident_penalty_pct=float(100 * (pue[top1].mean() / pue.mean() - 1)),
                                coincident_uplift_MW_central=float(it * (pue[top1].mean() - pue.mean())))
    r['hourly_regional'] = hr

    # ---------- daily: state maximum demand vs hub daily Tmax ----------
    tmax = Ti[s].resample('D').max()
    hwthr = tmax.quantile(0.95)
    sd = st[STATE[s]].dropna()
    sd = sd[sd > 0.3 * sd.rolling(30, min_periods=5, center=True).median()]  # drop obvious parse errors
    k = sd.index.intersection(tmax.index)
    sd, tm = sd.loc[k], tmax.loc[k]
    srel = sd / sd.groupby(sd.index.year).transform('mean')
    top = top_within_year(sd, 0.95)    # ~18 highest-demand days per year
    rec = sd.groupby(sd.index.year).idxmax()
    r['daily_state'] = dict(state=STATE[s], days=int(len(k)), corr_Tmax_demand_relative=float(np.corrcoef(tm, srel)[0, 1]),
                            mean_Tmax_all=float(tm.mean()), mean_Tmax_top5pct_days=float(tm[top].mean()),
                            share_top5pct_days_that_are_heat_days=float(100 * (tm[top] >= hwthr).mean()),
                            share_all_days_that_are_heat_days=float(100 * (tm >= hwthr).mean()),
                            top5_by_month=pd.Series(sd.index.month[top.values]).value_counts().sort_index().to_dict(),
                            annual_peak_days={str(y): dict(date=f'{d:%Y-%m-%d}', MW=float(sd[d]), Tmax=float(tm[d]))
                                              for y, d in rec.items()},
                            peak_MW_2025=float(sd[sd.index.year == 2025].max()),
                            heat_threshold_C=float(hwthr), n_heat_days=int((tm >= hwthr).sum()),
                            state_demand_on_heat_days_pct_of_year_peak=float(100 * (sd[tm >= hwthr] / sd.groupby(sd.index.year).transform('max')[tm >= hwthr]).mean()))
    out['sites'][s] = r

# Southern Region: combined Hyderabad + Chennai data centre load in the region's top 1% demand hours
dem = h[REGION['Hyderabad']]; j = dem.index.intersection(Ti.index); dem = dem.loc[j]
top1 = top_within_year(dem, 0.99).values
comb = {}
for tech in TECHS:
    tot, fix = np.zeros(len(j)), 0.0
    for s in ('Hyderabad', 'Chennai'):
        Tdb = Ti[s].loc[j].values; pue, _, _ = pue_wue(Tdb, wetbulb(Tdb, RHi[s].loc[j].values), CENTRAL, tech)
        it = (INV[s]['live'] + 0.6 * INV[s]['pipeline']) * CENTRAL['u']
        tot += it * pue; fix += it * pue.mean()
    comb[tech] = dict(load_top1_MW=float(tot[top1].mean()), fixedPUE_MW=float(fix), uplift_MW=float(tot[top1].mean() - fix))
out['southern_region_combined_central'] = comb

# Phoenix on the same within-year basis (AZPS + SRP, EIA-930, UTC throughout)
gd = cache['gd']; Tp = T['Phoenix'].values; ok = T['Phoenix'].reindex(gd.index).notna()
dem = gd[ok]; top = top_within_year(dem, 0.99)
out['phoenix_coincident_penalty_pct'] = {}
for tech in TECHS:
    pue, _, _ = pue_wue(Tp, wetbulb(Tp, RH['Phoenix'].values), CENTRAL, tech)
    ps = pd.Series(pue, T.index).reindex(dem.index)
    out['phoenix_coincident_penalty_pct'][tech] = float(100 * (ps[top].mean() / pue.mean() - 1))
json.dump(out, open('results_india_grid.json', 'w'), indent=1, default=str)

for s, r in out['sites'].items():
    a, b = r['hourly_regional'], r['daily_state']
    print(s, a['region'], 'corr', round(a['corr_T_demand_relative'], 2), 'T all/top1', round(a['mean_T_all'], 1), round(a['mean_T_top1pct_demand_hours'], 1),
          'top1 in hot10 %', round(a['share_top1_demand_hours_in_hottest10pct'], 1), 'mode hr', a['peak_hour_of_day_mode'], 'months', a['top1_by_month'])
    print('   ', {t: round(v['coincident_penalty_pct'], 2) for t, v in a['tech'].items()})
    print('   ', b['state'], 'corr', round(b['corr_Tmax_demand_relative'], 2), 'Tmax all/top', round(b['mean_Tmax_all'], 1), round(b['mean_Tmax_top5pct_days'], 1),
          'heatday share top/all', round(b['share_top5pct_days_that_are_heat_days'], 1), round(b['share_all_days_that_are_heat_days'], 1), 'months', b['top5_by_month'])
    print('    annual peaks', {y: (v['date'], v['MW'], round(v['Tmax'], 1)) for y, v in b['annual_peak_days'].items()})
print(json.dumps(comb, indent=0))
