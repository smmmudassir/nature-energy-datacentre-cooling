"""Fig 5: when the Indian grid peaks versus when cooling works hardest."""
import json, io, contextlib, sys, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.argv = ['x', sys.argv[1] if len(sys.argv) > 1 else '../upl_zip']
with contextlib.redirect_stdout(io.StringIO()):
    import figs  # noqa: F401  (shared style; regenerates figs 1-4)
    from india_grid import Ti, st, STATE
from figs import C, INK, MUTED, save
r = json.load(open('results_india_grid.json')); r0 = json.load(open('results.json'))

fig, axes = plt.subplots(1, 2, figsize=(7.6, 3.4), gridspec_kw={'wspace': 0.45, 'width_ratios': [1.25, 1]})
ax = axes[0]; ax2 = ax.twinx(); m = np.arange(1, 13)
for i, (s, stn) in enumerate(STATE.items()):
    sd = st[stn].dropna(); rel = 100 * sd / sd.groupby(sd.index.year).transform('max')
    ax.plot(m, rel.groupby(rel.index.month).mean().reindex(m), color=C[i], lw=2, label=f'{stn} demand')
tmax = Ti['Hyderabad'].resample('D').max(); hd = tmax >= tmax.quantile(0.95)
ax2.bar(m, 100 * hd.groupby(hd.index.month).mean().reindex(m).fillna(0), 0.6, color='#d9d8d3', zorder=0)
ax.set_zorder(ax2.get_zorder() + 1); ax.patch.set_visible(False)
ax2.set_ylabel('Hyderabad heat days (% of days)', color=MUTED); ax2.spines['right'].set_visible(True); ax2.grid(False)
ax.set_xticks(m, list('JFMAMJJASOND')); ax.set_ylabel('Mean daily peak demand\n(% of that year\'s maximum)')
ax.set_title('a  State demand and Hyderabad heat, by month', loc='left', fontsize=9)
ax.legend(frameon=False, fontsize=7, loc='upper center', bbox_to_anchor=(0.5, -0.12), ncol=3)
ax = axes[1]; hubs = ['Hyderabad', 'Mumbai', 'Chennai', 'Phoenix']; x = np.arange(4); t = 'Air-cooled chiller'
hot = [r0['sites'][s]['tech'][t]['heat_penalty_pct'] for s in hubs]
co = [r['sites'][s]['hourly_regional']['tech'][t]['coincident_penalty_pct'] for s in hubs[:3]] + [r['phoenix_coincident_penalty_pct'][t]]
ax.bar(x - 0.18, hot, 0.34, color='#9a9a9a', label='Hottest 1% of hours')
ax.bar(x + 0.18, co, 0.34, color=C[0], label='Grid\'s top 1% demand hours')
ax.set_xticks(x, ['Hyder-\nabad', 'Mumbai', 'Chennai', 'Phoenix'], fontsize=8)
ax.set_ylabel('Air-cooled PUE vs annual mean (%)'); ax.set_title('b  Heat penalty at the grid peak', loc='left', fontsize=9)
ax.legend(frameon=False, fontsize=7, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=1)
save(fig, '5_india_coincidence')
