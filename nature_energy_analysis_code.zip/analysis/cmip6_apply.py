"""Apply CMIP6 monthly change signals (2041-2060 vs 2015-2024) to hourly ERA5 and recompute hottest-hour PUE and load."""
import json, numpy as np, pandas as pd
from model import pue_wue, wetbulb, rh_from, td_from, CENTRAL, TECHS, INV, SITES

d = json.load(open('cmip6_deltas.json'))
cache = pd.read_pickle('cache.pkl'); T, RH = cache['T'], cache['RH']
month = T.index.month.values - 1
out = {'models': list(d), 'sites': {}}
for s in SITES:
    Tdb0 = T[s].values; RH0 = RH[s].values
    hot0 = Tdb0 >= np.quantile(Tdb0, 0.99)
    it = (INV[s]['live'] + 0.6 * INV[s]['pipeline']) * CENTRAL['u']
    site = {}
    for tech in TECHS:
        p0, _, _ = pue_wue(Tdb0, wetbulb(Tdb0, RH0), CENTRAL, tech)
        base_hot = p0[hot0].mean()
        row = {'baseline_pue_hot1': float(base_hot)}
        for ssp in ('ssp245', 'ssp585'):
            ch_pct, ch_mw, dts = [], [], []
            for m in d:
                dT = np.array(d[m][ssp][s]['dT'])[month]
                dRH = np.array(d[m][ssp][s]['dRH'])[month]
                Tf = Tdb0 + dT
                RHf = np.clip(RH0 + dRH, 1, 100)
                pf, _, _ = pue_wue(Tf, wetbulb(Tf, RHf), CENTRAL, tech)
                hotf = Tf >= np.quantile(Tf, 0.99)      # hottest 1% of hours in the future climate
                ch_pct.append(100 * (pf[hotf].mean() / base_hot - 1))
                ch_mw.append(it * (pf[hotf].mean() - base_hot))
                dts.append(float(np.mean(d[m][ssp][s]['dT'])))
            q = lambda a: [float(np.percentile(a, x)) for x in (10, 50, 90)]
            row[ssp] = dict(pue_hot1_change_pct=q(ch_pct), peak_load_change_MW_central=q(ch_mw), annual_dT=q(dts))
        site[tech] = row
    out['sites'][s] = site
json.dump(out, open('results_cmip6.json', 'w'), indent=1)
for s in SITES:
    for tech in TECHS:
        r = out['sites'][s][tech]
        print(s, tech, 'dT245', [round(x, 2) for x in r['ssp245']['annual_dT']], 'PUE%245', [round(x, 2) for x in r['ssp245']['pue_hot1_change_pct']],
              'PUE%585', [round(x, 2) for x in r['ssp585']['pue_hot1_change_pct']], 'MW585', [round(x) for x in r['ssp585']['peak_load_change_MW_central']])
