"""Sensitivity of direct-to-chip liquid cooling results to facility-water supply temperature (ASHRAE W40 vs W45) and liquid capture fraction."""
import json, io, contextlib, sys, numpy as np, pandas as pd
import model
sys.argv = ['x', sys.argv[1] if len(sys.argv) > 1 else '../upl_zip']
with contextlib.redirect_stdout(io.StringIO()):
    from india_grid import Ti, RHi, h, REGION, top_within_year
T, RH, gd = (pd.read_pickle('cache.pkl')[k] for k in ('T', 'RH', 'gd'))
CASES = {'W40, 75% liquid (central)': (40.0, 0.75), 'W45, 75% liquid': (45.0, 0.75), 'W45, 90% liquid': (45.0, 0.90)}
tech = 'Direct-to-chip liquid'
out = {}
for case, (sup, frac) in CASES.items():
    model.LIQ_SET, model.LIQ_FRAC = sup, frac
    res = {}
    for s in model.SITES:
        Tdb = T[s].values; Twb = model.wetbulb(Tdb, RH[s].values)
        pue, _, _ = model.pue_wue(Tdb, Twb, model.CENTRAL, tech)
        air, _, _ = model.pue_wue(Tdb, Twb, model.CENTRAL, 'Air-cooled chiller')
        hot = Tdb >= np.quantile(Tdb, 0.99)
        it = (model.INV[s]['live'] + 0.6 * model.INV[s]['pipeline']) * model.CENTRAL['u']
        r = dict(pue_mean=float(pue.mean()), pue_hot1=float(pue[hot].mean()),
                 heat_penalty_pct=float(100 * (pue[hot].mean() / pue.mean() - 1)),
                 peak_reduction_vs_air_pct=float(100 * (1 - pue[hot].mean() / air[hot].mean())),
                 hours_above_supply_limit_per_yr=float((Tdb > sup - model.CENTRAL['approach']).sum() / (len(Tdb) / 8766)))
        # coincident penalty at the grid's top 1% demand hours, ranked within year
        if s == 'Phoenix':
            ps = pd.Series(pue, T.index).reindex(gd.index).dropna(); dem = gd.reindex(ps.index)
        else:
            Ts = Ti[s]; dem = h[REGION[s]]; j = dem.index.intersection(Ts.index); dem = dem.loc[j]
            ps = pd.Series(model.pue_wue(Ts.loc[j].values, model.wetbulb(Ts.loc[j].values, RHi[s].loc[j].values), model.CENTRAL, tech)[0], j)
        top = top_within_year(dem, 0.99)
        r['coincident_penalty_pct'] = float(100 * (ps[top].mean() / pue.mean() - 1))
        r['hot1_uplift_MW_central'] = float(it * (pue[hot].mean() - pue.mean()))
        res[s] = r
    out[case] = res
json.dump(out, open('results_liquid_sensitivity.json', 'w'), indent=1)
for c, res in out.items():
    print(c)
    for s, r in res.items():
        print(f"  {s:10s} PUE {r['pue_mean']:.3f} hot {r['pue_hot1']:.3f} pen {r['heat_penalty_pct']:5.1f}% coinc {r['coincident_penalty_pct']:5.1f}% vsAir {r['peak_reduction_vs_air_pct']:5.1f}% uplift {r['hot1_uplift_MW_central']:6.0f} MW hrs>{r['hours_above_supply_limit_per_yr']:.0f}")
