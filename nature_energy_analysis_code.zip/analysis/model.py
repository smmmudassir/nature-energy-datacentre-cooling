"""First-pass model: weather-driven data centre cooling, water use and peak-hour impact.

Inputs: ERA5 hourly 2 m temperature / dew point (era5_cache/), EIA-930 hourly demand
for AZPS+SRP (eia930_azps_srp.csv), and a public-source capacity inventory (below).
"""
import glob, json, numpy as np, pandas as pd

rng = np.random.default_rng(42)
SITES = ['Hyderabad', 'Mumbai', 'Chennai', 'Phoenix']

# ---------------------------------------------------------------- inventory (IT MW)
# Sources: Knight Frank India Data Centre Market Update 2025 (end-2025 live, pipeline);
# JLL North America Data Center Report midyear 2025 via AZ Corporation Commission (Phoenix
# under construction 1,307 MW, planned 4,154 MW; existing ~1,030 MW derived from 3% = 31 MW vacancy).
INV = {
    'Hyderabad': dict(live=151.4, pipeline=1900.0),
    'Mumbai':    dict(live=766.6, pipeline=1543.3 + 2209.0),
    'Chennai':   dict(live=191.5, pipeline=1040.0),
    'Phoenix':   dict(live=1030.0, pipeline=1307.0 + 4154.0),
}
# Recent record state / system peaks (MW): Telangana 20,003 (15 Oct 2026); Tamil Nadu 21,724
# (15 Jul 2026); Maharashtra 32,317 (May 2026 monthly peak); Phoenix from EIA-930 below.
STATE_PEAK = {'Hyderabad': 20003.0, 'Mumbai': 32317.0, 'Chennai': 21724.0}
STATE_NAME = {'Hyderabad': 'Telangana', 'Mumbai': 'Maharashtra', 'Chennai': 'Tamil Nadu', 'Phoenix': 'AZPS+SRP'}

# ---------------------------------------------------------------- parameters
CENTRAL = dict(u=0.7, f_aux=0.07, cop_air=3.2, cop_wc=6.0, k=0.10, approach=4.0, c_fan=0.05, coc=4.0)
RANGES = dict(u=(0.5, 0.9), f_aux=(0.04, 0.10), cop_air=(2.6, 3.8), cop_wc=(5.0, 7.0),
              k=(0.05, 0.15), approach=(2.0, 6.0), c_fan=(0.03, 0.08), coc=(3.0, 6.0))
CHW_SET = 18.0      # chilled-water supply set-point (°C) for economiser logic
LIQ_SET = 40.0      # facility water supply for direct-to-chip liquid cooling, ASHRAE W40 class (°C)
LIQ_FRAC = 0.75     # share of heat captured by liquid loop
BAND = 3.0          # partial-economiser transition band (°C)
SCEN = {'2025 live': 0.0, 'Central build-out (60%)': 0.6, 'Full build-out (100%)': 1.0}


# ---------------------------------------------------------------- weather
def load_weather():
    def stack(var):
        fs = sorted(glob.glob(f'era5_cache/{var}_*.csv'))
        return pd.concat([pd.read_csv(f, index_col=0, parse_dates=True) for f in fs]).sort_index()
    T, Td = stack('2t'), stack('2d')
    idx = T.index.intersection(Td.index)
    return T.loc[idx], Td.loc[idx]


def rh_from(T, Td):
    a, b = 17.625, 243.04
    return 100 * np.exp(a * Td / (b + Td) - a * T / (b + T))


def td_from(T, RH):
    a, b = 17.625, 243.04
    g = np.log(np.clip(RH, 1, 100) / 100) + a * T / (b + T)
    return b * g / (a - g)


def wetbulb(T, RH):  # Stull (2011)
    RH = np.clip(RH, 5, 99)
    return (T * np.arctan(0.151977 * np.sqrt(RH + 8.313659)) + np.arctan(T + RH) - np.arctan(RH - 1.676331)
            + 0.00391838 * RH ** 1.5 * np.arctan(0.023101 * RH) - 4.686035)


def econ(Tout, setp, approach):
    full = setp - approach
    return np.clip((full + BAND - Tout) / BAND, 0, 1)


# ---------------------------------------------------------------- cooling archetypes
def pue_wue(Tdb, Twb, p, tech):
    """Return (PUE, on-site WUE in L/kWh_IT, chiller-compressor share of P_IT) arrays."""
    cop_air = np.clip(p['cop_air'] - p['k'] * (Tdb - 35.0), 1.5, 8.0)
    cop_wc = np.clip(p['cop_wc'] - p['k'] * (Twb - 24.0), 2.5, 10.0)
    wue = np.zeros_like(Tdb)
    if tech == 'Air-cooled chiller':
        e = econ(Tdb, CHW_SET, p['approach'])
        chill = (1 - e) / cop_air
    elif tech == 'Evaporative (water-cooled)':
        e = econ(Twb, CHW_SET, p['approach'])
        chill = (1 - e) / cop_wc
        q_rej = 1 + chill                                   # heat rejected per unit IT
        latent = np.clip(0.75 + 0.01 * (Twb - 15), 0.6, 0.9)
        evap = q_rej * 3600 / 2450 * latent                 # L per kWh_IT
        wue = evap * (1 + 1 / (p['coc'] - 1))
    elif tech == 'Direct-to-chip liquid':
        e_liq = econ(Tdb, LIQ_SET, p['approach'])
        e_air = econ(Tdb, CHW_SET, p['approach'])
        chill = LIQ_FRAC * (1 - e_liq) / cop_air + (1 - LIQ_FRAC) * (1 - e_air) / cop_air
    else:
        raise ValueError(tech)
    c_fan = p['c_fan'] * (0.8 if tech == 'Direct-to-chip liquid' else 1.0)
    pue = 1 + p['f_aux'] + chill + c_fan
    return pue, wue, chill


TECHS = ['Air-cooled chiller', 'Evaporative (water-cooled)', 'Direct-to-chip liquid']


def draw_params(n):
    out = []
    for _ in range(n):
        out.append({k: rng.uniform(*RANGES[k]) for k in RANGES})
    return out


def main():
    T, Td = load_weather()
    RH = rh_from(T, Td)
    years = f'{T.index.min():%Y-%m}–{T.index.max():%Y-%m}'
    res = dict(weather_period=years, n_hours=len(T), sites={})
    hourly = {}

    # Phoenix grid demand (local time MST = UTC-7, no DST)
    g = pd.read_csv('eia930_azps_srp.csv', parse_dates=['datetime_utc'])
    g['d'] = g.demand_imputed_pudl_mwh.fillna(g.demand_reported_mwh)
    gd = g.pivot_table(index='datetime_utc', columns='balancing_authority_code_eia', values='d').dropna()
    gd = gd.sum(axis=1)
    gd = gd[(gd > gd.quantile(0.001)) & (gd < gd.quantile(0.99999))]

    for s in SITES:
        Tdb, Twb = T[s].values, wetbulb(T[s].values, RH[s].values)
        idx = T.index
        hot1 = Tdb >= np.quantile(Tdb, 0.99)          # hottest 1% of hours
        # heat events: days whose daily max exceeds the site's 95th percentile of daily max
        dmax = pd.Series(Tdb, idx).resample('D').max()
        hw_days = set(dmax[dmax >= dmax.quantile(0.95)].index.date)
        hw = np.array([d in hw_days for d in idx.date])
        site = dict(state=STATE_NAME[s], inventory=INV[s], climate=dict(
            mean_T=float(Tdb.mean()), p99_T=float(np.quantile(Tdb, 0.99)), mean_Twb=float(Twb.mean()),
            p99_Twb=float(np.quantile(Twb, 0.99))), tech={})
        if s == 'Phoenix':
            loc = pd.Series(Tdb, idx).reindex(gd.index)  # both UTC
            ok = loc.notna().values
            dem = gd.values[ok]
            top1 = dem >= np.quantile(dem, 0.99)
            site['grid'] = dict(hours=int(ok.sum()), peak_MW=float(dem.max()), mean_MW=float(dem.mean()),
                                corr_T_demand=float(np.corrcoef(loc.values[ok], dem)[0, 1]),
                                mean_T_top1pct_demand_hours=float(loc.values[ok][top1].mean()))
        for tech in TECHS:
            pue, wue, chill = pue_wue(Tdb, Twb, CENTRAL, tech)
            # warming: +1 and +2 °C at constant RH
            warm = {}
            for dT in (1.0, 2.0):
                Tw = Tdb + dT
                Tdw = td_from(Tw, RH[s].values)
                pw, ww, _ = pue_wue(Tw, wetbulb(Tw, rh_from(Tw, Tdw)), CENTRAL, tech)
                warm[f'+{dT:.0f}C'] = dict(pue_hot1=float(pw[hot1].mean()), pue_mean=float(pw.mean()),
                                           wue_mean=float(ww.mean()))
            t = dict(pue_mean=float(pue.mean()), pue_hot1=float(pue[hot1].mean()), pue_heatwave=float(pue[hw].mean()),
                     pue_max=float(pue.max()), wue_mean=float(wue.mean()), wue_hot1=float(wue[hot1].mean()),
                     econ_hours_per_year=float(((chill < 1e-9).sum()) / (len(pue) / 8766)),
                     heat_penalty_pct=float(100 * (pue[hot1].mean() / pue.mean() - 1)),
                     warming=warm)
            # PUE slope with temperature above 25 °C (per °C)
            m = Tdb > 25
            if m.sum() > 100:
                t['pue_slope_per_C_above25'] = float(np.polyfit(Tdb[m], pue[m], 1)[0])
            # scenario loads (MW)
            sc = {}
            for name, frac in SCEN.items():
                it = INV[s]['live'] + frac * INV[s]['pipeline']
                load = it * CENTRAL['u'] * pue
                d = dict(IT_MW=it, mean_MW=float(load.mean()), hot1_MW=float(load[hot1].mean()),
                         fixedPUE_MW=float(it * CENTRAL['u'] * pue.mean()),
                         cooling_uplift_hot1_MW=float(load[hot1].mean() - it * CENTRAL['u'] * pue.mean()))
                if s in STATE_PEAK:
                    d['share_of_state_peak_hot1_pct'] = 100 * d['hot1_MW'] / STATE_PEAK[s]
                    d['share_of_state_peak_fixedPUE_pct'] = 100 * d['fixedPUE_MW'] / STATE_PEAK[s]
                else:
                    loadg = pd.Series(load, idx).reindex(gd.index).values[ok]
                    d['top1_demand_hours_MW'] = float(loadg[top1].mean())
                    d['share_of_system_peak_top1_pct'] = float(100 * (loadg[top1] / dem[top1]).mean())
                    d['fixedPUE_share_top1_pct'] = float(100 * (d['fixedPUE_MW'] / dem[top1]).mean())
                    d['peak_uplift_vs_fixedPUE_MW'] = float(loadg[top1].mean() - d['fixedPUE_MW'])
                sc[name] = d
            t['scenarios'] = sc
            site['tech'][tech] = t
            hourly[(s, tech)] = (Tdb, Twb, pue, wue)
        res['sites'][s] = site

    # mitigation at central build-out, hottest 1% hours (Phoenix: top 1% demand hours)
    mit = {}
    for s in SITES:
        it = INV[s]['live'] + 0.6 * INV[s]['pipeline']
        Tdb, Twb = T[s].values, wetbulb(T[s].values, RH[s].values)
        sel = Tdb >= np.quantile(Tdb, 0.99)
        if s == 'Phoenix':
            loc = pd.Series(Tdb, T.index).reindex(gd.index); ok = loc.notna().values
            dem = gd.values[ok]; top1 = dem >= np.quantile(dem, 0.99)
        base_p, base_w, base_c = pue_wue(Tdb, Twb, CENTRAL, 'Air-cooled chiller')

        def at_peak(arr):
            if s == 'Phoenix':
                return float(pd.Series(arr, T.index).reindex(gd.index).values[ok][top1].mean())
            return float(arr[sel].mean())
        base = at_peak(it * CENTRAL['u'] * base_p)
        opts = {}
        for tech in TECHS[1:]:
            p_, w_, _ = pue_wue(Tdb, Twb, CENTRAL, tech)
            opts[f'Switch to {tech.lower()}'] = dict(peak_MW=at_peak(it * CENTRAL['u'] * p_),
                                                    water_ML_per_year=float((it * CENTRAL['u'] * 1000 * w_).sum() / (len(w_) / 8766) / 1e6))
        # 4-hour chilled-water storage: removes chiller compressor load during peak hours
        opts['4-h thermal storage (air-cooled)'] = dict(peak_MW=at_peak(it * CENTRAL['u'] * (base_p - base_c)), water_ML_per_year=0.0)
        # shift 20% of IT load (and its cooling) out of peak hours
        opts['Shift 20% of IT load'] = dict(peak_MW=at_peak(0.8 * it * CENTRAL['u'] * base_p), water_ML_per_year=0.0)
        for k, v in opts.items():
            v['reduction_pct'] = 100 * (1 - v['peak_MW'] / base)
            v['reduction_MW'] = base - v['peak_MW']
        mit[s] = dict(baseline_air_cooled_peak_MW=base, options=opts)
    res['mitigation_central'] = mit

    # Monte Carlo uncertainty: central build-out, air-cooled & evaporative, hottest 1% hours
    mc = {}
    P = draw_params(1000)
    for s in SITES:
        Tdb, Twb = T[s].values, wetbulb(T[s].values, RH[s].values)
        sel = Tdb >= np.quantile(Tdb, 0.99)
        out = {}
        for tech in TECHS:
            pen, mw = [], []
            for p in P:
                frac = rng.uniform(0.3, 0.9)
                it = INV[s]['live'] + frac * INV[s]['pipeline']
                pue, _, _ = pue_wue(Tdb, Twb, p, tech)
                pen.append(100 * (pue[sel].mean() / pue.mean() - 1))
                mw.append(it * p['u'] * (pue[sel].mean() - pue.mean()))
            out[tech] = dict(heat_penalty_pct=[float(np.percentile(pen, q)) for q in (5, 50, 95)],
                             cooling_uplift_MW=[float(np.percentile(mw, q)) for q in (5, 50, 95)])
        mc[s] = out
    res['monte_carlo'] = mc

    json.dump(res, open('results.json', 'w'), indent=1)
    pd.to_pickle(dict(T=T, RH=RH, gd=gd), 'cache.pkl')
    print(json.dumps({s: {t: {k: res['sites'][s]['tech'][t][k] for k in ('pue_mean', 'pue_hot1', 'heat_penalty_pct', 'wue_mean')}
                          for t in TECHS} for s in SITES}, indent=1))


if __name__ == '__main__':
    main()
