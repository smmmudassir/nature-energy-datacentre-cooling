"""Extract hourly ERA5 2 m temperature and dew point at study sites from the NSF-NCAR ERA5 mirror on AWS."""
import fsspec, h5py, numpy as np, pandas as pd, sys, os
from multiprocessing import Pool

SITES = {  # lat, lon (0-360)
    'Hyderabad': (17.45, 78.38),
    'Mumbai': (19.10, 72.90),
    'Chennai': (13.00, 80.20),
    'Phoenix': (33.45, 360 - 112.05),
}
VARS = {'2t': '128_167_2t', '2d': '128_168_2d'}
BASE = 'https://nsf-ncar-era5.s3.us-west-2.amazonaws.com/e5.oper.an.sfc'
OUT = 'era5_cache'
os.makedirs(OUT, exist_ok=True)


def month_end(y, m):
    return pd.Timestamp(y, m, 1).days_in_month


def fetch(args):
    y, m, var = args
    out = f'{OUT}/{var}_{y}{m:02d}.csv'
    if os.path.exists(out):
        return out
    code = VARS[var]
    url = f'{BASE}/{y}{m:02d}/e5.oper.an.sfc.{code}.ll025sc.{y}{m:02d}0100_{y}{m:02d}{month_end(y, m)}23.nc'
    for attempt in range(4):
        try:
            with fsspec.open(url, block_size=2**20).open() as f, h5py.File(f, 'r') as h:
                key = [k for k in h.keys() if k.startswith('VAR_')][0]
                lat = h['latitude'][:]; lon = h['longitude'][:]
                t = pd.to_datetime(h['time'][:], unit='h', origin='1900-01-01')
                cols = {}
                for s, (la, lo) in SITES.items():
                    i = int(np.abs(lat - la).argmin()); j = int(np.abs(lon - lo).argmin())
                    cols[s] = h[key][:, i, j] - 273.15
                pd.DataFrame(cols, index=t).to_csv(out)
                return out
        except Exception as e:
            err = e
    print('FAILED', url, err, file=sys.stderr)


if __name__ == '__main__':
    jobs = [(y, m, v) for y in range(2015, 2026) for m in range(1, 13) for v in VARS]
    with Pool(8) as ex:
        for i, r in enumerate(ex.imap_unordered(fetch, jobs)):
            if i % 20 == 0:
                print(i, r, flush=True)
    print('done')
